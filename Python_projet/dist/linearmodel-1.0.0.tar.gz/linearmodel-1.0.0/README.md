In the first part, I used a class Matrix and a loader function to import the data, then numpy for the second part to be able to inverse the matrix X.
I defined all the function and class used for statistics and visualization in two files statistics.py and visualization.py and the class Matrix with the load in the file dataframe.py.
Then I summerized all the results in the file main.py.